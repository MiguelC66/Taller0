//
// Created by elmig on 07/09/2025.
//
#ifndef UNTITLED_MUSICA_H
#define UNTITLED_MUSICA_H

#include <string>
using namespace std;

class Musica {

private:
    string nombre;
    string album;
    string artista;
    int duracionSeg; // en segundos

public:
    // Constructor
    Musica(string nombre, string album, string artista, int duracionSeg);

    // Getters
    string getNombre() const;
    string getAlbum() const;
    string getArtista() const;
    int getDuracionSeg() const;

    // Setters (por valor; permiten move interno y eliminamos &)
    void setNombre(string nuevoNombre);
    void setAlbum(string nuevoAlbum);
    void setArtista(string nuevoArtista);
    void setDuracionSeg(int nuevaDuracion);

    // Utilidad para imprimir
    string toString() const;
};

#endif //UNTITLED_MUSICA_H
