#ifndef UNTITLED_SISTEMA_H
#define UNTITLED_SISTEMA_H

#include <vector>
#include <string>
#include "../Usuario.h"
#include "../BibliotecaMusical.h"

using namespace std;

class Sistema {
private:
    vector<Usuario> listaUsuarios;
    BibliotecaMusical biblioteca;
    Usuario* usuarioActual; // nullptr cuando no hay sesión iniciada

public:
    Sistema();

    // Carga de datos
    int cargarCanciones(std::string rutaCancionesCSV); // delega a BibliotecaMusical
    int cargarUsuarios(std::string rutaUsuariosCSV);   // lee CSV con encabezado

    // Gestión de usuarios
    bool registrarUsuario(std::string nombreUsuario,
                          std::string correo,
                          std::string contrasenia);
    bool iniciarSesion(std::string nombreUsuario,
                       std::string contrasenia);
    void cerrarSesion();

    // Accesos
    BibliotecaMusical& getBiblioteca() { return biblioteca; }
    const Usuario* getUsuarioActual() const { return usuarioActual; }
    bool haySesion() const { return usuarioActual != nullptr; }

    // Helpers opcionales
    void listarUsuarios() const;

    // ----- Playlists del usuario actual -----
    bool crearPlaylist(std::string nombre);
    bool eliminarPlaylist(std::string nombre);
    void listarPlaylists() const;

    bool agregarCancionAPlaylist(std::string nombrePlaylist,
                                 std::string nombreCancion);
    bool eliminarCancionDePlaylist(std::string nombrePlaylist,
                                   std::string nombreCancion);
    void listarCancionesDePlaylist(std::string nombrePlaylist) const;
};

#endif // UNTITLED_SISTEMA_H
