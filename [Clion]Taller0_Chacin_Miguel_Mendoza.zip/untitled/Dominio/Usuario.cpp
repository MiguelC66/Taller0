#include "Usuario.h"

bool Usuario::agregarPlaylist(string nombre) {
    if ((int)playlists.size() >= 3) return false;
    for (const auto& playlist : playlists) {
        if (playlist.getNombre() == nombre) return false;
    }
    playlists.emplace_back(nombre);
    return true;
}

bool Usuario::eliminarPlaylist(string nombre) {
    for (size_t i = 0; i < playlists.size(); ++i) {
        if (playlists[i].getNombre() == nombre) {
            playlists.erase(playlists.begin() + (long)i);
            return true;
        }
    }
    return false;
}

Playlist* Usuario::buscarPlaylist(string nombre) {
    for (auto& playlist : playlists) {
        if (playlist.getNombre() == nombre) return &playlist;
    }
    return nullptr;
}
