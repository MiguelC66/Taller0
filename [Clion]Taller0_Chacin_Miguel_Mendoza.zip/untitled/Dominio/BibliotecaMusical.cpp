//
// Created by elmig on 07/09/2025.
//

#include "BibliotecaMusical.h"

#include <iostream>
#include <fstream>
#include <sstream>

using namespace std;

BibliotecaMusical::BibliotecaMusical() {}

bool BibliotecaMusical::agregarCancion(Musica musica) {
    listaCanciones.push_back(musica);
    return true;
}

Musica* BibliotecaMusical::buscarPorNombre(string nombre) {
    for (auto& musica : listaCanciones) {
        if (musica.getNombre() == nombre) {
            return &musica;  // dirección en std list
        }
    }
    return nullptr;
}

bool BibliotecaMusical::eliminarPorNombre(string nombre) {
    for (auto it = listaCanciones.begin(); it != listaCanciones.end(); ++it) {
        if (it->getNombre() == nombre) {
            listaCanciones.erase(it);
            return true;
        }
    }
    return false;
}

void BibliotecaMusical::listar() const {
    if (listaCanciones.empty()) {
        cout << "(Biblioteca vacía)" << endl;
        return;
    }

    int indice = 1;
    for (const auto& musica : listaCanciones) {
        cout << indice << ". " << musica.toString() << endl;
        indice++;
    }
}

int BibliotecaMusical::cargarDesdeArchivo(string rutaArchivo) {
    ifstream archivo(rutaArchivo);
    if (!archivo.is_open()) {
        cerr << "No se pudo abrir el archivo: " << rutaArchivo << endl;
        return 0;
    }

    string linea;
    int cantidadCargada = 0;

    getline(archivo, linea); // salta encabezado, la lectura me fallaba por espacios y ;

    while (getline(archivo, linea)) {
        stringstream ss(linea);
        string nombre, album, artista, duracionTexto;

        getline(ss, nombre, ',');
        getline(ss, album, ',');
        getline(ss, artista, ',');
        getline(ss, duracionTexto, ',');

        int minutos = 0, segundos = 0;
        char separador = ':';
        stringstream duracionStream(duracionTexto);
        duracionStream >> minutos >> separador >> segundos;
        int duracionSegundos = minutos * 60 + segundos;

        Musica musica(nombre, album, artista, duracionSegundos);
        agregarCancion(musica);
        cantidadCargada++;
    }

    return cantidadCargada;
}