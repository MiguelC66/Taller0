//
// Created by elmig on 07/09/2025.
//
#ifndef UNTITLED_BIBLIOTECAMUSICAL_H
#define UNTITLED_BIBLIOTECAMUSICAL_H

#include <list>
#include <string>
#include "Musica.h"

using namespace std;

class BibliotecaMusical {
private:
    list<Musica> listaCanciones;

public:
    BibliotecaMusical();

    bool agregarCancion(Musica musica);
    Musica* buscarPorNombre(string nombre);
    bool eliminarPorNombre(string nombre);
    void listar() const;

    int cargarDesdeArchivo(string rutaArchivo);
};

#endif //UNTITLED_BIBLIOTECAMUSICAL_H