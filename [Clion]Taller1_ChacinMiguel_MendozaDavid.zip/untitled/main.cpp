#include "Dominio/Sistema/Sistema.h"  // porque pusiste Sistema dentro de Dominio
#include "Dominio/Vista/Vista.h"      // Vista también está dentro de Dominio
#include <iostream>
using namespace std;

int main() {
    // Crear el sistema
    Sistema sistema;

    // Cargar datos desde archivos
    int usuariosCargados  = sistema.cargarUsuarios("users.txt");
    int cancionesCargadas = sistema.cargarCanciones("canciones.txt");

    cout << "Usuarios cargados: " << usuariosCargados << endl;
    cout << "Canciones cargadas: " << cancionesCargadas << endl;

    // Crear vista y mostrar menú
    Vista vista(&sistema);
    vista.mostrarMenuPrincipal();

    return 0;
}