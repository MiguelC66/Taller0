//
// Created by elmig on 07/09/2025.
//

#include "NodoSimple.h"
#include "Musica.h"



NodoSimple::NodoSimple(Musica* dato)
    : dato(dato), siguiente(nullptr) {}


Musica *NodoSimple::getDato() const {
    return dato;
}

NodoSimple *NodoSimple::getSiguiente() const {
    return siguiente;
}

void NodoSimple::setSiguiente(NodoSimple* nodo) {
    siguiente = nodo;
}


