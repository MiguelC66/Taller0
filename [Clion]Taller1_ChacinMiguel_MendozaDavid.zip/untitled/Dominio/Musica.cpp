//
// Created by elmig on 07/09/2025.
//

#include "Musica.h"

#include <sstream>

using namespace std;

Musica::Musica(string nombre, string album, string artista, int duracionSeg)
    : nombre(nombre), album(album), artista(artista), duracionSeg(duracionSeg) {}

string Musica::getNombre() const {
    return nombre;
}

string Musica::getAlbum() const {
    return album;
}

string Musica::getArtista() const {
    return artista;
}

int Musica::getDuracionSeg() const {
    return duracionSeg;
}

void Musica::setNombre(const string& nuevoNombre) {
    nombre = nuevoNombre;
}

void Musica::setAlbum(const string& nuevoAlbum) {
    album = nuevoAlbum;
}

void Musica::setArtista(const string& nuevoArtista) {
    artista = nuevoArtista;
}

void Musica::setDuracionSeg(int nuevaDuracion) {
    duracionSeg = nuevaDuracion;
}

string Musica::toString() const {
    return nombre + " - " + artista + " (" + album + ", " + to_string(duracionSeg) + "s)";
}