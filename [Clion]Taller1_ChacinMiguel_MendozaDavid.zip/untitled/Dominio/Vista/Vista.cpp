//
// Created by elmig on 07/09/2025.
//

#include "Vista.h"
#include <iostream>

using namespace std;

Vista::Vista(Sistema* sistema) : sistema(sistema) {}

void Vista::mostrarMenuPrincipal() {
    int opcion;
    do {
        cout << "\n===== MENU PRINCIPAL =====\n";
        cout << "1. Iniciar sesion\n";
        cout << "2. Registrar usuario\n";
        cout << "3. Ver biblioteca musical\n";
        cout << "0. Salir\n";
        cout << "Seleccione una opcion: ";
        cin >> opcion;
        cin.ignore(); // limpia el buffer

        switch (opcion) {
            case 1: {
                string nombre, contrasenia;
                cout << "Nombre de usuario: ";
                getline(cin, nombre);
                cout << "Contrasenia: ";
                getline(cin, contrasenia);

                if (sistema->iniciarSesion(nombre, contrasenia)) {
                    cout << "Sesion iniciada como " << nombre << "\n";
                    mostrarMenuUsuario();
                } else {
                    cout << "Error: usuario o contrasenia incorrectos.\n";
                }
                break;
            }
           case 2: {
    string nombre, correo, contrasenia;
    cout << "Nombre de usuario: ";
    getline(cin, nombre);
    cout << "Correo: ";
    getline(cin, correo);
    cout << "Contrasenia: ";
    getline(cin, contrasenia);

    if (sistema->registrarUsuario(nombre, correo, contrasenia)) {
        cout << "Usuario registrado con exito.\n";
    } else {

        cout << "No se pudo registrar. Revise el mensaje anterior.\n";
    }
    break;
}
            case 3:
                mostrarMenuBiblioteca();
                break;
            case 0:
                cout << "Saliendo del sistema...\n";
                break;
            default:
                cout << "Opcion no valida.\n";
        }
    } while (opcion != 0);
}

void Vista::mostrarMenuUsuario() {
    int opcion;
    do {
        cout << "\n===== MENU USUARIO =====\n";
        cout << "1. Playlists\n";
        cout << "2. Ver biblioteca musical\n";
        cout << "3. Cerrar sesion\n";
        cout << "0. Volver al menu principal\n";
        cout << "Seleccione una opcion: ";
        cin >> opcion;
        cin.ignore();

        switch (opcion) {
            case 1:
                mostrarMenuPlaylists();
                break;
            case 2:
                mostrarMenuBiblioteca();
                break;
            case 3:
                sistema->cerrarSesion();
                cout << "Sesion cerrada.\n";
                return; // salir directamente al menu principal
            case 0:
                return;
            default:
                cout << "Opcion no valida.\n";
        }
    } while (opcion != 0);
}

void Vista::mostrarMenuBiblioteca() {
    cout << "\n===== BIBLIOTECA MUSICAL =====\n";
    sistema->getBiblioteca().listar();
}

// Nuevo Submenu de Playlists
void Vista::mostrarMenuPlaylists() {
    int opcion;
    do {
        cout << "\n===== PLAYLISTS =====\n";
        cout << "1. Crear playlist\n";
        cout << "2. Eliminar playlist\n";
        cout << "3. Listar playlists\n";
        cout << "4. Agregar cancion a playlist\n";
        cout << "5. Eliminar cancion de playlist\n";
        cout << "6. Listar canciones de una playlist\n";
        cout << "0. Volver\n";
        cout << "Seleccione una opcion: ";
        cin >> opcion;
        cin.ignore();

        switch (opcion) {
            case 1: {
                string nombre;
                cout << "Nombre de la nueva playlist: ";
                getline(cin, nombre);
                if (sistema->crearPlaylist(nombre)) {
                    cout << "Playlist creada.\n";
                } else {
                    cout << "No se pudo crear (ya existe o alcanzaste el maximo de 3).\n";
                }
                break;
            }
            case 2: {
                string nombre;
                cout << "Nombre de la playlist a eliminar: ";
                getline(cin, nombre);
                if (sistema->eliminarPlaylist(nombre)) {
                    cout << "Playlist eliminada.\n";
                } else {
                    cout << "No existe una playlist con ese nombre.\n";
                }
                break;
            }
            case 3: {
                sistema->listarPlaylists();
                break;
            }
            case 4: {
                string nombrePl, nombreCancion;
                cout << "Nombre de la playlist: ";
                getline(cin, nombrePl);
                cout << "Titulo de la cancion (como en la biblioteca): ";
                getline(cin, nombreCancion);
                if (sistema->agregarCancionAPlaylist(nombrePl, nombreCancion)) {
                    cout << "Cancion agregada.\n";
                } else {
                    cout << "No se pudo agregar (playlist o cancion inexistente).\n";
                }
                break;
            }
            case 5: {
                string nombrePl, nombreCancion;
                cout << "Nombre de la playlist: ";
                getline(cin, nombrePl);
                cout << "Titulo de la cancion a eliminar: ";
                getline(cin, nombreCancion);
                if (sistema->eliminarCancionDePlaylist(nombrePl, nombreCancion)) {
                    cout << "Cancion eliminada.\n";
                } else {
                    cout << "No se pudo eliminar (no encontrada o playlist inexistente).\n";
                }
                break;
            }
            case 6: {
                string nombrePl;
                cout << "Nombre de la playlist: ";
                getline(cin, nombrePl);
                sistema->listarCancionesDePlaylist(nombrePl);
                break;
            }
            case 0:
                return;
            default:
                cout << "Opcion no valida.\n";
        }
    } while (opcion != 0);
}