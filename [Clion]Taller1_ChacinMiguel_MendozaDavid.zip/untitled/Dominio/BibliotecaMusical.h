//
// Created by elmig on 07/09/2025.
//

#ifndef UNTITLED_BIBLIOTECAMUSICAL_H
#define UNTITLED_BIBLIOTECAMUSICAL_H
#include <vector>
#include <string>
#include "Musica.h"

using namespace std;

class BibliotecaMusical {

private:
    vector<Musica> listaCanciones;

public:
    BibliotecaMusical();

    bool agregarCancion(const Musica& musica);
    Musica* buscarPorNombre(const string& nombre);
    bool eliminarPorNombre(const string& nombre);
    void listar() const;


    int cargarDesdeArchivo(const string& rutaArchivo);



};


#endif //UNTITLED_BIBLIOTECAMUSICAL_H