//
// Created by elmig on 07/09/2025.
//

#ifndef UNTITLED_PLAYLIST_H
#define UNTITLED_PLAYLIST_H

#include <string>
#include "Musica.h"
#include "ListaEnlazada.h"

using namespace std;

class Playlist {
private:
    string nombre;
    ListaEnlazada canciones; // guarda punteros a Musica que estan en la Biblioteca

public:
    // Constructor
    explicit Playlist(const string& nombre);

    // Getters/Setters
    string getNombre() const;
    void setNombre(const string& nuevoNombre);

    // Operaciones sobre canciones
    bool agregarCancion(Musica* cancion);               // agrega al final
    bool eliminarCancion(const string& nombreCancion);  // elimina primera coincidencia
    void listarCanciones() const;                       // imprime por consola

    // Utilidades
    int getCantidad() const;     // cantidad de canciones en la lista
    bool estaVacia() const;



};


#endif //UNTITLED_PLAYLIST_H