//
// Created by elmig on 07/09/2025.
//

#include "Playlist.h"

#include <iostream>

using namespace std;

Playlist::Playlist(const string& nombre) : nombre(nombre) {}

string Playlist::getNombre() const {
    return nombre;
}

void Playlist::setNombre(const string& nuevoNombre) {
    nombre = nuevoNombre;
}

bool Playlist::agregarCancion(Musica* cancion) {
    if (cancion == nullptr) return false;

    canciones.insertarFin(cancion);
    return true;
}

bool Playlist::eliminarCancion(const string& nombreCancion) {
    return canciones.eliminarPorNombre(nombreCancion);
}

void Playlist::listarCanciones() const {
    cout << "=== Playlist: " << nombre << " ===\n";
    canciones.listar();
}

int Playlist::getCantidad() const {
    return canciones.getTamano();
}

bool Playlist::estaVacia() const {
    return canciones.estaVacia();
}