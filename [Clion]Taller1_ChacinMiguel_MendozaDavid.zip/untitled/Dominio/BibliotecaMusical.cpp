//
// Created by elmig on 07/09/2025.
//

#include "BibliotecaMusical.h"


#include <iostream>
#include <fstream>
#include <sstream>

using namespace std;

BibliotecaMusical::BibliotecaMusical() {}

bool BibliotecaMusical::agregarCancion(const Musica& musica) {
    listaCanciones.push_back(musica);
    return true;
}

Musica* BibliotecaMusical::buscarPorNombre(const string& nombre) {
    for (auto& musica : listaCanciones) {
        if (musica.getNombre() == nombre) {
            return &musica;
        }
    }
    return nullptr;
}

bool BibliotecaMusical::eliminarPorNombre(const string& nombre) {
    for (size_t i = 0; i < listaCanciones.size(); i++) {
        if (listaCanciones[i].getNombre() == nombre) {
            listaCanciones.erase(listaCanciones.begin() + i);
            return true;
        }
    }
    return false;
}

void BibliotecaMusical::listar() const {
    if (listaCanciones.empty()) {
        cout << "(Biblioteca vacía)" << endl;
        return;
    }

    int indice = 1;
    for (const auto& musica : listaCanciones) {
        cout << indice << ". " << musica.toString() << endl;
        indice++;
    }
}

int BibliotecaMusical::cargarDesdeArchivo(const string& rutaArchivo) {
    ifstream archivo(rutaArchivo);
    if (!archivo.is_open()) {
        cerr << "No se pudo abrir el archivo: " << rutaArchivo << endl;
        return 0;
    }

    string linea;
    int cantidadCargada = 0;

    // Saltar la primera línea (encabezado)
    getline(archivo, linea);

    while (getline(archivo, linea)) {
        stringstream ss(linea);
        string nombre, album, artista, duracionTexto;

        getline(ss, nombre, ',');
        getline(ss, album, ',');
        getline(ss, artista, ',');
        getline(ss, duracionTexto, ',');

        // convertir "3:16" a segundos
        int minutos = 0, segundos = 0;
        char separador;
        stringstream duracionStream(duracionTexto);
        duracionStream >> minutos >> separador >> segundos;
        int duracionSegundos = minutos * 60 + segundos;

        Musica musica(nombre, album, artista, duracionSegundos);
        agregarCancion(musica);
        cantidadCargada++;
    }

    return cantidadCargada;
}