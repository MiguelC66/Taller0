#ifndef UNTITLED_SISTEMA_H
#define UNTITLED_SISTEMA_H

#include <vector>
#include <string>
#include "../Usuario.h"
#include "../BibliotecaMusical.h"

using namespace std;

class Sistema {
private:
    vector<Usuario> listaUsuarios;
    BibliotecaMusical biblioteca;
    Usuario* usuarioActual; // nullptr cuando no hay sesión iniciada

public:
    Sistema();

    // Carga de datos
    int cargarCanciones(const string& rutaCancionesCSV); // delega a BibliotecaMusical
    int cargarUsuarios(const string& rutaUsuariosCSV);   // lee CSV con encabezado

    // Gestión de usuarios
    bool registrarUsuario(const string& nombreUsuario,
                          const string& correo,
                          const string& contrasenia);
    bool iniciarSesion(const string& nombreUsuario,
                       const string& contrasenia);
    void cerrarSesion();

    // Accesos
    BibliotecaMusical& getBiblioteca() { return biblioteca; }
    const Usuario* getUsuarioActual() const { return usuarioActual; }
    bool haySesion() const { return usuarioActual != nullptr; }

    // Helpers opcionales
    void listarUsuarios() const;





    // ----- Playlists del usuario actual -----
    bool crearPlaylist(const std::string& nombre);
    bool eliminarPlaylist(const std::string& nombre);
    void listarPlaylists() const;

    bool agregarCancionAPlaylist(const std::string& nombrePlaylist,
                                 const std::string& nombreCancion);
    bool eliminarCancionDePlaylist(const std::string& nombrePlaylist,
                                   const std::string& nombreCancion);
    void listarCancionesDePlaylist(const std::string& nombrePlaylist) const;






};

#endif // UNTITLED_SISTEMA_H