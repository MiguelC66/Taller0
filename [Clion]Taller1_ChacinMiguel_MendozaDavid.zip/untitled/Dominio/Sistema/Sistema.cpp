//
// Created by elmig on 07/09/2025.
//

#include "Sistema.h"
#include <fstream>
#include <sstream>
#include <iostream>

using namespace std;



// Helpers en un namespace anónimo para no tocar headers
namespace {
    bool esCorreoValido(const std::string& correo) {
        // Debe contener '@' y terminar con ".com"
        if (correo.find('@') == std::string::npos) return false;
        const std::string sufijo = ".com";
        if (correo.size() < sufijo.size()) return false;
        return correo.compare(correo.size() - sufijo.size(), sufijo.size(), sufijo) == 0;
    }

    bool esContraseniaValida(const std::string& pass) {
        bool tieneMayus = false, tieneNumero = false, tieneSimbolo = false;
        for (unsigned char ch : pass) {
            if (std::isupper(ch))   tieneMayus = true;
            else if (std::isdigit(ch)) tieneNumero = true;
            else if (!std::isalnum(ch)) tieneSimbolo = true; // cualquier no alfanumérico
        }
        return tieneMayus && tieneNumero && tieneSimbolo;
    }

    bool existeUsuario(const std::vector<Usuario>& usuarios, const std::string& nombre) {
        for (const auto& u : usuarios) {
            if (u.getNombreDeUsuario() == nombre) return true;
        }
        return false;
    }

    // Genera base, base1, base2, ... hasta encontrar uno libre
    std::string generarSugerenciaNombre(const std::string& base,
                                        const std::vector<Usuario>& usuarios) {
        if (!existeUsuario(usuarios, base)) return base; // en caso

        // Intenta base + número incremental
        for (int n = 1; n <= 9999; ++n) {
            std::string candidato = base + std::to_string(n);
            if (!existeUsuario(usuarios, candidato)) return candidato;
        }
        // Fallback poco probable
        return base + "_nuevo";
    }
}











Sistema::Sistema()
    : usuarioActual(nullptr) {}

//  Carga de datos

int Sistema::cargarCanciones(const string& rutaCanciones) {
    // Reusa el lector simple tipo CSV con encabezado que ya se hizo en BibliotecaMusical
    return biblioteca.cargarDesdeArchivo(rutaCanciones);
}

int Sistema::cargarUsuarios(const string& rutaUsuariosCSV) {
    ifstream archivo(rutaUsuariosCSV);
    if (!archivo.is_open()) {
        cerr << "No se pudo abrir el archivo de usuarios: " << rutaUsuariosCSV << "\n";
        return 0;
    }

    string linea;
    int usuariosCargados = 0;

    // Saltar encabezado (primera línea)
    if (!getline(archivo, linea)) {
        return 0; // archivo vacío
    }

    while (getline(archivo, linea)) {
        if (linea.empty()) continue;

        // Detectar si la línea usa ',' o ';' como separador
        char separador = (linea.find(';') != string::npos) ? ';' : ',';

        string idTexto, nombreUsuario, correo, contrasenia;
        stringstream parser(linea);

        if (!getline(parser, idTexto, separador)) continue;
        if (!getline(parser, nombreUsuario, separador)) continue;
        if (!getline(parser, correo, separador)) continue;
        if (!getline(parser, contrasenia, separador)) continue;

        if (registrarUsuario(nombreUsuario, correo, contrasenia)) {
            usuariosCargados++;
        }
    }

    return usuariosCargados;
}


// --------------- Gestión de usuarios ---------------

bool Sistema::registrarUsuario(const std::string& nombreUsuario,
                               const std::string& correo,
                               const std::string& contrasenia) {
    // Validación de correo
    if (!esCorreoValido(correo)) {
        std::cout << "Registro fallido: el correo debe contener '@' y terminar en '.com'.\n";
        return false;
    }

    // Validación de contraseña
    if (!esContraseniaValida(contrasenia)) {
        std::cout << "Registro fallido: la contrasenia debe tener al menos "
                     "1 mayuscula, 1 numero y 1 simbolo.\n";
        return false;
    }

    // Si pasó las validaciones anteriores, recién revisa duplicados
    if (existeUsuario(listaUsuarios, nombreUsuario)) {
        std::string sugerido = generarSugerenciaNombre(nombreUsuario, listaUsuarios);
        std::cout << "Registro fallido: ya existe un usuario con el nombre '"
                  << nombreUsuario << "'. Sugerencia: '" << sugerido << "'.\n";
        return false;
    }

    // registrar
    listaUsuarios.emplace_back(nombreUsuario, correo, contrasenia);
    return true;
}

bool Sistema::iniciarSesion(const string& nombreUsuario,
                            const string& contrasenia) {
    for (auto& u : listaUsuarios) {
        if (u.getNombreDeUsuario() == nombreUsuario &&
            u.getContrasenia() == contrasenia) {
            usuarioActual = &u;
            return true;
        }
    }
    return false;
}

void Sistema::cerrarSesion() {
    usuarioActual = nullptr;
}


//  Helpers

void Sistema::listarUsuarios() const {
    if (listaUsuarios.empty()) {
        cout << "(no hay usuarios cargados)\n";
        return;
    }
    int indice = 1;
    for (const auto& usuario : listaUsuarios) {
        cout << indice++ << ". "
             << usuario.getNombreDeUsuario()
             << " <" << usuario.getCorreo() << ">\n";
    }
}




//  Playlists del usuario actual

bool Sistema::crearPlaylist(const std::string& nombre) {
    if (!usuarioActual) return false;
    return usuarioActual->agregarPlaylist(nombre); // limite 3, no duplicados
}

bool Sistema::eliminarPlaylist(const std::string& nombre) {
    if (!usuarioActual) return false;
    return usuarioActual->eliminarPlaylist(nombre);
}

void Sistema::listarPlaylists() const {
    if (!usuarioActual) {
        std::cout << "Debe iniciar sesion.\n";
        return;
    }
    const auto& pls = usuarioActual->getPlaylists();
    if (pls.empty()) {
        std::cout << "(sin playlists)\n";
        return;
    }
    for (size_t i = 0; i < pls.size(); ++i) {
        std::cout << (i + 1) << ". " << pls[i].getNombre()
                  << " (" << pls[i].getCantidad() << " canciones)\n";
    }
}

bool Sistema::agregarCancionAPlaylist(const std::string& nombrePlaylist,
                                      const std::string& nombreCancion) {
    if (!usuarioActual) return false;

    Playlist* pl = usuarioActual->buscarPlaylist(nombrePlaylist);
    if (!pl) return false;

    Musica* musica = biblioteca.buscarPorNombre(nombreCancion);
    if (!musica) return false;

    return pl->agregarCancion(musica);
}

bool Sistema::eliminarCancionDePlaylist(const std::string& nombrePlaylist,
                                        const std::string& nombreCancion) {
    if (!usuarioActual) return false;

    Playlist* pl = usuarioActual->buscarPlaylist(nombrePlaylist);
    if (!pl) return false;

    return pl->eliminarCancion(nombreCancion);
}

void Sistema::listarCancionesDePlaylist(const std::string& nombrePlaylist) const {
    if (!usuarioActual) {
        std::cout << "Debe iniciar sesion.\n";
        return;
    }
    // buscar playlist
    Usuario* ua = const_cast<Usuario*>(usuarioActual); //casteo a const
    Playlist* pl = ua->buscarPlaylist(nombrePlaylist);
    if (!pl) {
        std::cout << "No existe la playlist '" << nombrePlaylist << "'.\n";
        return;
    }
    std::cout << "=== Playlist: " << pl->getNombre() << " ===\n";
    pl->listarCanciones();
}