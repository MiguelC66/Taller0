#pragma once
#include <string>
#include <stdexcept>
#include <vector>
#include "Playlist.h"

using std::string;
using std::vector;

class Usuario {
private:
    string nombreDeUsuario;
    string correo;
    string contrasenia;

    vector<Playlist> playlists;   // para 3 playlists

public:
    Usuario() = default;

    // Constructor
    Usuario(const string& nombre, const string& correo, const string& contrasenia)
        : nombreDeUsuario(nombre), correo(correo), contrasenia(contrasenia) {
        if (nombreDeUsuario.empty()) throw std::invalid_argument("nombre vacío");
        if (correo.empty())          throw std::invalid_argument("correo vacío");
        if (contrasenia.empty())     throw std::invalid_argument("contraseña vacía");
    }

    // Getters
    const string& getNombreDeUsuario() const { return nombreDeUsuario; }
    const string& getCorreo()          const { return correo; }
    const string& getContrasenia()     const { return contrasenia; }

    // Setters
    void setNombreDeUsuario(const string& v) {
        if (v.empty()) throw std::invalid_argument("nombre vacío");
        nombreDeUsuario = v;
    }
    void setCorreo(const string& v) {
        if (v.empty()) throw std::invalid_argument("correo vacío");
        correo = v;
    }
    void setContrasenia(const string& v) {
        if (v.empty()) throw std::invalid_argument("contraseña vacía");
        contrasenia = v;
    }

    //  playlists
    bool agregarPlaylist(const string& nombre);
    bool eliminarPlaylist(const string& nombre);
    Playlist* buscarPlaylist(const string& nombre);
    const vector<Playlist>& getPlaylists() const { return playlists; }
    int getCantidadPlaylists() const { return (int)playlists.size(); }
};